/*
 * Drawable.cpp
 *
 *  Created on: Oct 6, 2009
 */

#include "Drawable.h"

Drawable::Drawable() {

}

Drawable::~Drawable() {
}
