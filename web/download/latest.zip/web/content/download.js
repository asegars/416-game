var c_download = "<h2>Download Rising Tide</h2> \
<p>As an open source software project, Rising Tide is available as a public code repository and a downloadable archive.</p> \
<h3>Code Repository</h3> \
<p>The source code for Rising Tide is available at Github as a public read-only repository.  Clone the repository at <a href='git://github.com/asegars/416-game.git'>git://github.com/asegars/416-game.git</a> for a full copy of the source code.</p> \
<h3>Downloadable Archive</h3> \
<p>The source code is also available as a <a href='download/latest.zip'>zipped archive</a>.  </p>";