var c_media = "<h2>Screenshots & Videos</h2> \
	<h3>Screenshots</h3> \
 	<div style='border-width: 0px;' id='images'> \
		<p>Some action shots from inside the game:</p> \
		<img src='media/ss1.jpg' style='width: 480px; height: 360px; border: 1px solid black;' /> \
		<p style='width: 100%; text-align: center;'>Screenshot 1: A player vaporizes a monster with an oversized laser gun.</p> \
		<img src='media/ss2.jpg' style='width: 480px; height: 360px; border: 1px solid black;' /> \
		<p style='width: 100%; text-align: center;'>Screenshot 2: There's no hiding when the waters start rising.</p> \
		<img src='media/ss3.jpg' style='width: 480px; height: 360px; border: 1px solid black;' /> \
		<p style='width: 100%; text-align: center;'>Screenshot 3: The lucky survivor makes a mad dash for the hovercraft.</p> \
		 \
		 \
	</div> \
	<h3>Gameplay Videos</h3> \
		<p>The well-known and widely cherished gameplay video:</p> \
	";
