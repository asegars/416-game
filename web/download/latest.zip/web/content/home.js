var c_home = "<img src='images/bigwave.jpg' style='width: 180px; height: 295px; float: left;'/> \
	<h2>Rising Tide: The Game</h2> \
	<p>Rising Tide pits the player against the forces of an oncoming flood, forcing them to \
	constantly climb higher and higher in each level to reach the safety of a hovercraft.  As you \
	might expect, savage monsters also appear with the flood, making patience and indecision and \
	dangerous choice.</p> \
	<p>A tough challenge for experts and novices alike, Rising Tide offers:</p> \
	<p><ul> \
		<li>(Somewhat) intelligent monsters who want to see you dead.</li> \
		<li>A point system based on survival skills with floods and monsters.</li> \
		<li>A laser gun like none you've ever seen.</li> \
		<li>Customizable maps to allow for new challenges and high replayability.</li> \
	</ul></p> \
	\
	";
