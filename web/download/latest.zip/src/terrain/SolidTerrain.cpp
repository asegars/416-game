/*
 * SolidTerrain.cpp
 *
 *  Created on: Oct 28, 2009
 */

#include "SolidTerrain.h"

SolidTerrain::SolidTerrain() : Terrain(new Sprite("solid-terrain.bmp")) {
}

SolidTerrain::~SolidTerrain() {

}
