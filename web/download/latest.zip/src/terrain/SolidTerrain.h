/*
 * SolidTerrain.h
 *
 *  Created on: Oct 28, 2009
 *      Author: alsegars
 */

#ifndef SOLIDTERRAIN_H_
#define SOLIDTERRAIN_H_

#include "Terrain.h"

class SolidTerrain : public Terrain {
public:
	SolidTerrain();
	virtual ~SolidTerrain();
};

#endif /* SOLIDTERRAIN_H_ */
